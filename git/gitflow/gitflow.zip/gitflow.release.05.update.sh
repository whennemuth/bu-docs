cd "`dirname $0`"
sh -v gitflow.release.06.update.local.1.sh
sh -v gitflow.release.07.update.local.2.sh